package app.luma

object AppConfig {
    const val CREATOR = "Davi Esquitini"
    const val VERSION = "2.0"

    const val DEFAULT_MODEL = "openai/gpt-oss-20b"
    const val DEFAULT_VOICE_ID = "ef191366-f52f-447a-a398-ed8c0f2943a1"
    const val DEFAULT_USER_NAME = "Esquitini"

    // Opcional: cole aqui o "Client ID Web" do Google se quiser já vir preenchido.
    // Também dá para informar dentro do app (Configurações > Login com Google).
    const val DEFAULT_GOOGLE_WEB_CLIENT_ID = ""

    // Dados para cadastrar o app no Google Cloud (keystore fixa do projeto)
    const val PACKAGE_NAME = "app.luma"
    const val DEBUG_SHA1 = "7A:61:E1:36:A5:67:3C:F7:38:5E:34:3B:FB:79:48:5E:91:5F:C7:5B"

    const val GROQ_URL = "https://api.groq.com/openai/v1/chat/completions"
    const val CARTESIA_URL = "https://api.cartesia.ai/tts/bytes"
    const val CARTESIA_VERSION = "2025-04-16"
    const val CARTESIA_MODEL = "sonic-latest"
    const val SAMPLE_RATE = 24000

    const val HOTWORD_PATTERN = "\\b(luma|lumma|lhuma)\\b"
    const val END_PATTERN = "\\b(tchau|encerrar)\\b"
}

fun String.firstName(): String =
    trim().substringBefore(' ').ifBlank { AppConfig.DEFAULT_USER_NAME }
