package app.luma.data

import kotlinx.coroutines.flow.Flow

class ChatRepository(db: AppDatabase) {
    private val conversations = db.conversationDao()
    private val messages = db.messageDao()

    fun currentConversationId(): Flow<Long?> = conversations.latestIdFlow()

    fun messages(conversationId: Long): Flow<List<MessageEntity>> = messages.observe(conversationId)

    suspend fun newConversation(): Long =
        conversations.insert(ConversationEntity(title = "Conversa", createdAt = System.currentTimeMillis()))

    suspend fun ensureConversationId(): Long = conversations.latestId() ?: newConversation()

    suspend fun add(role: String, content: String, source: String): MessageEntity {
        val message = MessageEntity(
            conversationId = ensureConversationId(),
            role = role,
            content = content,
            source = source,
            createdAt = System.currentTimeMillis(),
        )
        return message.copy(id = messages.insert(message))
    }

    suspend fun history(limit: Int = 30): List<MessageEntity> =
        messages.list(ensureConversationId()).takeLast(limit)

    suspend fun clearAll() {
        messages.clear()
        conversations.clear()
    }
}
