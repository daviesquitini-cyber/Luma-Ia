package app.luma.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import app.luma.AppConfig
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.io.IOException

data class Settings(
    val apiKey: String = "",
    val cartesiaKey: String = "",
    val voiceId: String = AppConfig.DEFAULT_VOICE_ID,
    val model: String = AppConfig.DEFAULT_MODEL,
    val googleClientId: String = AppConfig.DEFAULT_GOOGLE_WEB_CLIENT_ID,
    val userName: String = "",
    val userEmail: String = "",
    val userPhoto: String = "",
    val onboarded: Boolean = false,
)

private val Context.lumaDataStore: DataStore<Preferences> by preferencesDataStore(name = "luma_settings")

class SettingsStore(private val context: Context) {

    private object K {
        val API_KEY = stringPreferencesKey("openAiKey")
        val CARTESIA_KEY = stringPreferencesKey("cartesiaKey")
        val VOICE_ID = stringPreferencesKey("voiceId")
        val MODEL = stringPreferencesKey("model")
        val GOOGLE_CLIENT_ID = stringPreferencesKey("googleClientId")
        val USER_NAME = stringPreferencesKey("userName")
        val USER_EMAIL = stringPreferencesKey("userEmail")
        val USER_PHOTO = stringPreferencesKey("userPhoto")
        val ONBOARDED = booleanPreferencesKey("onboarded")
    }

    val flow: Flow<Settings> = context.lumaDataStore.data
        .catch { e -> if (e is IOException) emit(emptyPreferences()) else throw e }
        .map { p ->
            Settings(
                apiKey = p[K.API_KEY].orEmpty(),
                cartesiaKey = p[K.CARTESIA_KEY].orEmpty(),
                voiceId = p[K.VOICE_ID]?.takeIf { it.isNotBlank() } ?: AppConfig.DEFAULT_VOICE_ID,
                model = p[K.MODEL]?.takeIf { it.isNotBlank() } ?: AppConfig.DEFAULT_MODEL,
                googleClientId = p[K.GOOGLE_CLIENT_ID]?.takeIf { it.isNotBlank() }
                    ?: AppConfig.DEFAULT_GOOGLE_WEB_CLIENT_ID,
                userName = p[K.USER_NAME].orEmpty(),
                userEmail = p[K.USER_EMAIL].orEmpty(),
                userPhoto = p[K.USER_PHOTO].orEmpty(),
                onboarded = p[K.ONBOARDED] ?: false,
            )
        }

    suspend fun current(): Settings = flow.first()

    /** Salva as configurações editáveis (chaves, modelo, voz, nome, client id). */
    suspend fun save(s: Settings) {
        context.lumaDataStore.edit { p ->
            p[K.API_KEY] = s.apiKey
            p[K.CARTESIA_KEY] = s.cartesiaKey
            p[K.VOICE_ID] = s.voiceId
            p[K.MODEL] = s.model
            p[K.GOOGLE_CLIENT_ID] = s.googleClientId
            p[K.USER_NAME] = s.userName
        }
    }

    suspend fun saveAccount(name: String, email: String, photo: String) {
        context.lumaDataStore.edit { p ->
            p[K.USER_NAME] = name
            p[K.USER_EMAIL] = email
            p[K.USER_PHOTO] = photo
            p[K.ONBOARDED] = true
        }
    }

    suspend fun clearAccount() {
        context.lumaDataStore.edit { p ->
            p[K.USER_EMAIL] = ""
            p[K.USER_PHOTO] = ""
        }
    }

    suspend fun setOnboarded(value: Boolean) {
        context.lumaDataStore.edit { p -> p[K.ONBOARDED] = value }
    }
}
