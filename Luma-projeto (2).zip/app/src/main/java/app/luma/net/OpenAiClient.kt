package app.luma.net

import app.luma.AppConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException
import java.net.UnknownHostException

/** Cliente de chat compatível com a API OpenAI (endpoint da Groq). */
class OpenAiClient(private val client: OkHttpClient = Http.client) {

    suspend fun chat(
        apiKey: String,
        model: String,
        system: String,
        turns: List<ChatTurn>,
    ): String {
        if (apiKey.isBlank()) throw ApiException("Configure a chave da API em Configurações.")
        val modelName = model.ifBlank { AppConfig.DEFAULT_MODEL }

        return withContext(Dispatchers.IO) {
            val messages = JSONArray()
            messages.put(JSONObject().put("role", "system").put("content", system))
            for (turn in turns) {
                messages.put(JSONObject().put("role", turn.role).put("content", turn.content))
            }
            val body = JSONObject()
                .put("model", modelName)
                .put("messages", messages)
                .put("temperature", 0.7)
            if (modelName.contains("gpt-oss", ignoreCase = true)) {
                body.put("reasoning_effort", "low")
            }

            val request = Request.Builder()
                .url(AppConfig.GROQ_URL)
                .header("Authorization", "Bearer ${apiKey.trim()}")
                .post(body.toString().toRequestBody("application/json".toMediaType()))
                .build()

            try {
                client.newCall(request).await().use { response ->
                    val text = response.body?.string().orEmpty()
                    if (!response.isSuccessful) {
                        throw ApiException("IA (${response.code}): ${apiErrorText(text)}")
                    }
                    val message = JSONObject(text)
                        .getJSONArray("choices")
                        .getJSONObject(0)
                        .getJSONObject("message")
                    if (message.isNull("content")) "" else message.getString("content").trim()
                }
            } catch (e: ApiException) {
                throw e
            } catch (e: UnknownHostException) {
                throw ApiException("Sem conexão com a internet.")
            } catch (e: IOException) {
                ensureActive()
                throw ApiException("Falha de rede: ${e.message}")
            } catch (e: JSONException) {
                throw ApiException("Resposta inválida da IA.")
            }
        }
    }
}
