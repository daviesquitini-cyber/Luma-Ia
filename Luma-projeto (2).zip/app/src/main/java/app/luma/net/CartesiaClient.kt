package app.luma.net

import app.luma.AppConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import java.net.UnknownHostException

/** Síntese de voz da Cartesia: devolve o áudio PCM 16-bit em pedaços (streaming). */
class CartesiaClient(private val client: OkHttpClient = Http.client) {

    suspend fun speak(
        apiKey: String,
        voiceId: String,
        text: String,
        onChunk: (ByteArray, Int) -> Unit,
    ) {
        if (apiKey.isBlank()) throw ApiException("Configure a chave da Cartesia em Configurações.")
        if (voiceId.isBlank()) throw ApiException("Configure o Voice ID da Cartesia em Configurações.")

        withContext(Dispatchers.IO) {
            val json = JSONObject()
                .put("model_id", AppConfig.CARTESIA_MODEL)
                .put("transcript", text)
                .put("voice", JSONObject().put("mode", "id").put("id", voiceId.trim()))
                .put("language", "pt")
                .put(
                    "output_format",
                    JSONObject()
                        .put("container", "raw")
                        .put("encoding", "pcm_s16le")
                        .put("sample_rate", AppConfig.SAMPLE_RATE),
                )

            val request = Request.Builder()
                .url(AppConfig.CARTESIA_URL)
                .header("Authorization", "Bearer ${apiKey.trim()}")
                .header("X-API-Key", apiKey.trim())
                .header("Cartesia-Version", AppConfig.CARTESIA_VERSION)
                .post(json.toString().toRequestBody("application/json".toMediaType()))
                .build()
            val call = client.newCall(request)

            try {
                coroutineScope {
                    // Se a coroutine for cancelada, interrompe a leitura bloqueante da rede.
                    val watcher = launch {
                        try {
                            awaitCancellation()
                        } finally {
                            call.cancel()
                        }
                    }
                    try {
                        call.await().use { response ->
                            if (!response.isSuccessful) {
                                val err = response.body?.string().orEmpty()
                                throw ApiException("Cartesia (${response.code}): ${apiErrorText(err)}")
                            }
                            val input = response.body?.byteStream()
                                ?: throw ApiException("Cartesia: resposta vazia.")
                            val buffer = ByteArray(8192)
                            while (true) {
                                ensureActive()
                                val n = input.read(buffer)
                                if (n < 0) break
                                if (n > 0) onChunk(buffer, n)
                            }
                        }
                    } finally {
                        watcher.cancel()
                    }
                }
            } catch (e: ApiException) {
                throw e
            } catch (e: UnknownHostException) {
                throw ApiException("Sem conexão com a internet.")
            } catch (e: IOException) {
                ensureActive()
                throw ApiException("Falha de rede (Cartesia): ${e.message}")
            }
        }
    }
}
