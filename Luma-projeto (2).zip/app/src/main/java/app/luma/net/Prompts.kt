package app.luma.net

import app.luma.firstName

object Prompts {
    fun system(userName: String, voice: Boolean): String {
        val base = "Você é a Luma, uma assistente pessoal simpática, inteligente e direta. " +
            "O usuário se chama ${userName.firstName()}. Responda sempre em português do Brasil."
        return if (voice) {
            "$base Esta é uma conversa por voz: responda de forma curta e natural " +
                "(no máximo 3 frases), sem markdown, listas, emojis ou símbolos."
        } else {
            base
        }
    }
}
