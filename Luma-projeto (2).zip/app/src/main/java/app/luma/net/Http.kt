package app.luma.net

import kotlinx.coroutines.suspendCancellableCoroutine
import okhttp3.Call
import okhttp3.Callback
import okhttp3.OkHttpClient
import okhttp3.Response
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

class ApiException(message: String) : Exception(message)

data class ChatTurn(val role: String, val content: String)

object Http {
    val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .build()
}

suspend fun Call.await(): Response = suspendCancellableCoroutine { cont ->
    val call = this
    cont.invokeOnCancellation { call.cancel() }
    call.enqueue(object : Callback {
        override fun onFailure(call: Call, e: IOException) {
            if (cont.isActive) cont.resumeWithException(e)
        }

        override fun onResponse(call: Call, response: Response) {
            if (cont.isActive) cont.resume(response) else response.close()
        }
    })
}

fun apiErrorText(body: String): String {
    if (body.isBlank()) return "sem detalhes"
    var text = body
    try {
        val json = JSONObject(body)
        val err = json.opt("error")
        text = when {
            err is JSONObject -> err.optString("message").ifBlank { body }
            err is String -> err
            json.has("message") -> json.optString("message")
            else -> body
        }
    } catch (e: Exception) {
        text = body
    }
    return text.take(300)
}
