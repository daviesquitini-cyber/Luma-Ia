package app.luma.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import app.luma.AppConfig
import app.luma.LumaApp
import app.luma.auth.GoogleAuth
import app.luma.auth.GoogleProfile
import app.luma.data.MessageEntity
import app.luma.data.Settings
import app.luma.net.ApiException
import app.luma.net.ChatTurn
import app.luma.net.OpenAiClient
import app.luma.net.Prompts
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ChatViewModel(application: Application) : AndroidViewModel(application) {

    private val luma = application as LumaApp
    private val repo = luma.repository
    private val store = luma.settingsStore
    private val openAi = OpenAiClient()

    val settings: StateFlow<Settings?> =
        store.flow.stateIn(viewModelScope, SharingStarted.Eagerly, null)

    @OptIn(ExperimentalCoroutinesApi::class)
    val messages: StateFlow<List<MessageEntity>> = repo.currentConversationId()
        .flatMapLatest { id ->
            if (id == null) flowOf(emptyList<MessageEntity>()) else repo.messages(id)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val _thinking = MutableStateFlow(false)
    val thinking: StateFlow<Boolean> = _thinking.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    fun dismissError() {
        _error.value = null
    }

    fun send(text: String) {
        val t = text.trim()
        if (t.isEmpty() || _thinking.value) return
        viewModelScope.launch {
            _error.value = null
            _thinking.value = true
            try {
                val s = store.current()
                repo.add("user", t, "text")
                val turns = repo.history().map { ChatTurn(it.role, it.content) }
                val reply = openAi.chat(
                    s.apiKey,
                    s.model,
                    Prompts.system(s.userName, voice = false),
                    turns,
                )
                repo.add("assistant", reply.ifBlank { "…" }, "text")
            } catch (e: CancellationException) {
                throw e
            } catch (e: ApiException) {
                _error.value = e.message
            } finally {
                _thinking.value = false
            }
        }
    }

    fun newConversation() {
        viewModelScope.launch { repo.newConversation() }
    }

    fun clearHistory() {
        viewModelScope.launch { repo.clearAll() }
    }

    fun saveConfig(s: Settings) {
        viewModelScope.launch {
            store.save(
                s.copy(
                    voiceId = s.voiceId.ifBlank { AppConfig.DEFAULT_VOICE_ID },
                    model = s.model.ifBlank { AppConfig.DEFAULT_MODEL },
                ),
            )
        }
    }

    fun signedIn(profile: GoogleProfile) {
        viewModelScope.launch { store.saveAccount(profile.name, profile.email, profile.photo) }
    }

    fun signOut() {
        viewModelScope.launch {
            GoogleAuth.signOut(luma)
            store.clearAccount()
        }
    }

    fun continueAsGuest() {
        viewModelScope.launch { store.setOnboarded(true) }
    }
}
