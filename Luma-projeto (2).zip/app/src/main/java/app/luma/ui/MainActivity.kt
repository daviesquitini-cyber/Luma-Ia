package app.luma.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import app.luma.auth.GoogleAuth
import app.luma.ui.theme.LumaTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            LumaTheme {
                LumaRoot(activity = this)
            }
        }
    }
}

@Composable
private fun LumaRoot(activity: ComponentActivity, vm: ChatViewModel = viewModel()) {
    val settings by vm.settings.collectAsStateWithLifecycle()
    val s = settings
    var showSettings by rememberSaveable { mutableStateOf(false) }
    var googleBusy by remember { mutableStateOf(false) }
    var googleError by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    BackHandler(enabled = showSettings) { showSettings = false }

    if (s == null) {
        Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background))
    } else {
        val signIn: () -> Unit = {
            if (!googleBusy) {
                scope.launch {
                    googleBusy = true
                    googleError = null
                    when (val result = GoogleAuth.signIn(activity, s.googleClientId)) {
                        is GoogleAuth.Result.Success -> vm.signedIn(result.profile)
                        is GoogleAuth.Result.Error -> googleError = result.message
                        GoogleAuth.Result.Cancelled -> Unit
                    }
                    googleBusy = false
                }
            }
        }

        val destination = when {
            showSettings -> 2
            !s.onboarded -> 0
            else -> 1
        }
        Crossfade(targetState = destination, label = "root") { dest ->
            when (dest) {
                0 -> LoginScreen(
                    busy = googleBusy,
                    error = googleError,
                    clientIdMissing = s.googleClientId.isBlank(),
                    onGoogle = signIn,
                    onGuest = { vm.continueAsGuest() },
                    onOpenSettings = { showSettings = true },
                )
                2 -> SettingsScreen(
                    settings = s,
                    googleBusy = googleBusy,
                    googleError = googleError,
                    onBack = { showSettings = false },
                    onSave = { vm.saveConfig(it) },
                    onClearHistory = { vm.clearHistory() },
                    onGoogleSignIn = signIn,
                    onSignOut = { vm.signOut() },
                )
                else -> ChatScreen(
                    vm = vm,
                    settings = s,
                    onOpenSettings = { showSettings = true },
                )
            }
        }
    }
}
