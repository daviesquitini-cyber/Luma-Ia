package app.luma.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import app.luma.ui.theme.LumaColors
import app.luma.voice.VoicePhase

@Composable
fun LoginScreen(
    busy: Boolean,
    error: String?,
    clientIdMissing: Boolean,
    onGoogle: () -> Unit,
    onGuest: () -> Unit,
    onOpenSettings: () -> Unit,
) {
    val scheme = MaterialTheme.colorScheme
    Box(Modifier.fillMaxSize()) {
        LumaBackground()
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 28.dp, vertical = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Spacer(Modifier.weight(1f))
            VoiceOrb(phase = VoicePhase.Waiting, diameter = 190.dp)
            Spacer(Modifier.size(24.dp))
            Text(
                "Luma",
                style = MaterialTheme.typography.displaySmall.copy(
                    brush = androidx.compose.ui.graphics.Brush.horizontalGradient(
                        listOf(LumaColors.Violet, LumaColors.Pink, LumaColors.Cyan),
                    ),
                ),
            )
            Spacer(Modifier.size(8.dp))
            Text(
                "Sua assistente pessoal por voz.\nDiga “Luma” e comece a conversar.",
                style = MaterialTheme.typography.bodyLarge,
                color = scheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.size(20.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Voz natural", "Histórico salvo", "Sempre por perto").forEach { label ->
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = scheme.surfaceContainer,
                        border = BorderStroke(1.dp, scheme.outlineVariant),
                    ) {
                        Text(
                            label,
                            Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            style = MaterialTheme.typography.labelMedium,
                            color = scheme.onSurfaceVariant,
                        )
                    }
                }
            }
            Spacer(Modifier.weight(1f))

            GoogleButton(onClick = onGoogle, busy = busy)
            error?.let {
                Spacer(Modifier.size(10.dp))
                Text(
                    it,
                    color = scheme.error,
                    style = MaterialTheme.typography.bodySmall,
                    textAlign = TextAlign.Center,
                )
            }
            if (clientIdMissing && error == null) {
                Spacer(Modifier.size(8.dp))
                Text(
                    "O login com Google ainda precisa ser configurado.",
                    color = scheme.onSurfaceVariant,
                    style = MaterialTheme.typography.bodySmall,
                    textAlign = TextAlign.Center,
                )
                TextButton(onClick = onOpenSettings) { Text("Configurar agora") }
            }
            TextButton(onClick = onGuest, modifier = Modifier.fillMaxWidth()) {
                Text("Entrar sem conta")
            }
        }
    }
}
