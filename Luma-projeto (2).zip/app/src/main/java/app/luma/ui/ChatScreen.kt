package app.luma.ui

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.MicOff
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.luma.data.MessageEntity
import app.luma.data.Settings
import app.luma.firstName
import app.luma.ui.theme.LumaColors
import app.luma.voice.VoicePhase
import app.luma.voice.VoiceService
import app.luma.voice.label
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private fun hasMic(context: Context): Boolean =
    ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
        PackageManager.PERMISSION_GRANTED

@Composable
fun ChatScreen(vm: ChatViewModel, settings: Settings, onOpenSettings: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val messages by vm.messages.collectAsStateWithLifecycle()
    val thinking by vm.thinking.collectAsStateWithLifecycle()
    val chatError by vm.error.collectAsStateWithLifecycle()
    val voice by VoiceService.state.collectAsStateWithLifecycle()

    var input by rememberSaveable { mutableStateOf("") }
    val listState = rememberLazyListState()
    val snackbar = remember { SnackbarHostState() }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions(),
    ) { result ->
        if (result[Manifest.permission.RECORD_AUDIO] == true || hasMic(context)) {
            VoiceService.start(context)
        } else {
            scope.launch { snackbar.showSnackbar("A permissão de microfone é necessária.") }
        }
    }

    val voiceOn = voice.phase != VoicePhase.Off
    val toggleVoice: () -> Unit = {
        if (voiceOn) {
            VoiceService.stop(context)
            scope.launch { snackbar.showSnackbar("Luma desativada") }
        } else if (hasMic(context)) {
            VoiceService.start(context)
        } else {
            val permissions = if (Build.VERSION.SDK_INT >= 33) {
                arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS)
            } else {
                arrayOf(Manifest.permission.RECORD_AUDIO)
            }
            permissionLauncher.launch(permissions)
        }
    }

    val showTyping = thinking || voice.phase == VoicePhase.Thinking
    val showGhost = voice.phase == VoicePhase.Listening && voice.transcript.isNotBlank()
    val itemCount = messages.size + (if (showTyping) 1 else 0) + (if (showGhost) 1 else 0)
    LaunchedEffect(itemCount) {
        if (itemCount > 0) listState.animateScrollToItem(itemCount - 1)
    }

    val orbPhase = if (thinking && voice.phase == VoicePhase.Off) VoicePhase.Thinking else voice.phase
    val statusText = if (thinking && voice.phase == VoicePhase.Off) {
        "Luma está digitando…"
    } else {
        voice.phase.label()
    }

    Box(Modifier.fillMaxSize()) {
        LumaBackground()
        Column(Modifier.fillMaxSize()) {
            ChatHeader(
                phase = orbPhase,
                status = statusText,
                onNew = vm::newConversation,
                onSettings = onOpenSettings,
            )
            voice.error?.let { ErrorBanner(it, onDismiss = { VoiceService.clearError() }) }
            chatError?.let { ErrorBanner(it, onDismiss = { vm.dismissError() }) }

            Box(Modifier.weight(1f).fillMaxWidth()) {
                if (messages.isEmpty() && !showTyping) {
                    EmptyState(
                        name = settings.userName.firstName(),
                        phase = orbPhase,
                        voiceOn = voiceOn,
                        needsSetup = settings.apiKey.isBlank(),
                        onOpenSettings = onOpenSettings,
                        onSuggestion = { vm.send(it) },
                    )
                } else {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        items(messages, key = { it.id }) { MessageBubble(it) }
                        if (showGhost) item { GhostBubble(voice.transcript) }
                        if (showTyping) item { TypingIndicator(statusText) }
                    }
                }
            }

            InputBar(
                value = input,
                onValueChange = { input = it },
                onSend = {
                    vm.send(input)
                    input = ""
                },
                phase = voice.phase,
                onToggleVoice = toggleVoice,
            )
        }
        SnackbarHost(
            hostState = snackbar,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .imePadding()
                .padding(bottom = 84.dp),
        ) { data -> Snackbar(snackbarData = data, shape = RoundedCornerShape(16.dp)) }
    }
}

@Composable
private fun ChatHeader(phase: VoicePhase, status: String, onNew: () -> Unit, onSettings: () -> Unit) {
    val scheme = MaterialTheme.colorScheme
    val dot = when (phase) {
        VoicePhase.Off -> scheme.outline
        VoicePhase.Waiting -> LumaColors.Emerald
        VoicePhase.Listening -> LumaColors.Cyan
        VoicePhase.Thinking -> LumaColors.Amber
        VoicePhase.Speaking -> LumaColors.Pink
    }
    Row(
        Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(start = 16.dp, end = 6.dp, top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        VoiceOrb(phase = phase, diameter = 48.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("Luma", style = MaterialTheme.typography.titleLarge, color = scheme.onBackground)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(8.dp).clip(CircleShape).background(dot))
                Spacer(Modifier.width(6.dp))
                Text(
                    status,
                    style = MaterialTheme.typography.labelMedium,
                    color = scheme.onSurfaceVariant,
                    maxLines = 1,
                )
            }
        }
        IconButton(onClick = onNew) {
            Icon(Icons.Rounded.Add, contentDescription = "Nova conversa", tint = scheme.onSurfaceVariant)
        }
        IconButton(onClick = onSettings) {
            Icon(Icons.Rounded.Settings, contentDescription = "Configurações", tint = scheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun ErrorBanner(text: String, onDismiss: () -> Unit) {
    Surface(
        color = MaterialTheme.colorScheme.errorContainer,
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp),
    ) {
        Row(
            Modifier.padding(start = 14.dp, top = 8.dp, bottom = 8.dp, end = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text,
                Modifier.weight(1f),
                color = MaterialTheme.colorScheme.onErrorContainer,
                style = MaterialTheme.typography.bodyMedium,
            )
            IconButton(onClick = onDismiss, modifier = Modifier.size(36.dp)) {
                Icon(
                    Icons.Rounded.Close,
                    contentDescription = "Fechar",
                    tint = MaterialTheme.colorScheme.onErrorContainer,
                )
            }
        }
    }
}

@Composable
private fun EmptyState(
    name: String,
    phase: VoicePhase,
    voiceOn: Boolean,
    needsSetup: Boolean,
    onOpenSettings: () -> Unit,
    onSuggestion: (String) -> Unit,
) {
    val scheme = MaterialTheme.colorScheme
    Column(
        Modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        VoiceOrb(phase = phase, diameter = 150.dp)
        Spacer(Modifier.size(20.dp))
        Text("Olá, $name", style = MaterialTheme.typography.headlineMedium, color = scheme.onBackground)
        Spacer(Modifier.size(6.dp))
        Text(
            text = if (voiceOn) {
                "Diga “Luma” para conversar ou escreva abaixo."
            } else {
                "Toque no microfone para ativar a Luma por voz, ou escreva uma mensagem."
            },
            style = MaterialTheme.typography.bodyLarge,
            color = scheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.size(24.dp))
        if (needsSetup) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = scheme.primaryContainer,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text(
                        "Comece configurando suas chaves",
                        style = MaterialTheme.typography.titleMedium,
                        color = scheme.onPrimaryContainer,
                    )
                    Spacer(Modifier.size(4.dp))
                    Text(
                        "Informe a chave da IA (Groq) e a da Cartesia para conversar e ouvir a Luma.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = scheme.onPrimaryContainer,
                    )
                    Spacer(Modifier.size(12.dp))
                    Button(onClick = onOpenSettings) { Text("Abrir configurações") }
                }
            }
        } else {
            listOf(
                "Me conte uma curiosidade",
                "Ajude-me a planejar meu dia",
                "Explique algo de um jeito simples",
            ).forEach { suggestion ->
                Surface(
                    onClick = { onSuggestion(suggestion) },
                    shape = RoundedCornerShape(18.dp),
                    color = scheme.surfaceContainer,
                    border = BorderStroke(1.dp, scheme.outlineVariant),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                ) {
                    Text(
                        suggestion,
                        Modifier.padding(horizontal = 18.dp, vertical = 14.dp),
                        color = scheme.onSurface,
                        style = MaterialTheme.typography.bodyMedium,
                    )
                }
            }
        }
    }
}

@Composable
private fun MessageBubble(m: MessageEntity) {
    val scheme = MaterialTheme.colorScheme
    val isUser = m.role == "user"
    val shape = if (isUser) {
        RoundedCornerShape(20.dp, 20.dp, 6.dp, 20.dp)
    } else {
        RoundedCornerShape(20.dp, 20.dp, 20.dp, 6.dp)
    }
    val time = remember(m.createdAt) {
        SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(m.createdAt))
    }
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start,
        verticalAlignment = Alignment.Bottom,
    ) {
        if (!isUser) {
            Box(
                Modifier.size(28.dp).clip(CircleShape).background(LumaGradient),
                contentAlignment = Alignment.Center,
            ) {
                Text("L", color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)
            }
            Spacer(Modifier.width(8.dp))
        }
        Column(
            Modifier.widthIn(max = 320.dp),
            horizontalAlignment = if (isUser) Alignment.End else Alignment.Start,
        ) {
            val bubbleModifier = if (isUser) {
                Modifier.clip(shape).background(LumaGradient)
            } else {
                Modifier.clip(shape).background(scheme.surfaceContainerHigh)
            }
            Box(bubbleModifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
                SelectionContainer {
                    Text(
                        m.content,
                        color = if (isUser) Color.White else scheme.onSurface,
                        style = MaterialTheme.typography.bodyLarge,
                    )
                }
            }
            Row(
                Modifier.padding(top = 3.dp, start = 4.dp, end = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                if (m.source == "voice") {
                    Icon(
                        Icons.Rounded.Mic,
                        contentDescription = "Por voz",
                        tint = scheme.outline,
                        modifier = Modifier.size(12.dp),
                    )
                    Spacer(Modifier.width(3.dp))
                }
                Text(time, style = MaterialTheme.typography.labelSmall, color = scheme.outline)
            }
        }
    }
}

@Composable
private fun GhostBubble(text: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
        Box(
            Modifier
                .widthIn(max = 320.dp)
                .clip(RoundedCornerShape(20.dp, 20.dp, 6.dp, 20.dp))
                .border(
                    1.dp,
                    MaterialTheme.colorScheme.primary.copy(alpha = 0.5f),
                    RoundedCornerShape(20.dp, 20.dp, 6.dp, 20.dp),
                )
                .padding(horizontal = 14.dp, vertical = 10.dp),
        ) {
            Text(
                text,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodyLarge,
            )
        }
    }
}

@Composable
private fun TypingIndicator(label: String) {
    Surface(
        shape = RoundedCornerShape(20.dp, 20.dp, 20.dp, 6.dp),
        color = MaterialTheme.colorScheme.surfaceContainerHigh,
    ) {
        Row(
            Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            TypingDots()
            Spacer(Modifier.width(10.dp))
            Text(
                label,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun InputBar(
    value: String,
    onValueChange: (String) -> Unit,
    onSend: () -> Unit,
    phase: VoicePhase,
    onToggleVoice: () -> Unit,
) {
    val scheme = MaterialTheme.colorScheme
    val pillShape = RoundedCornerShape(26.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .imePadding()
            .padding(start = 12.dp, end = 12.dp, top = 8.dp, bottom = 10.dp),
        verticalAlignment = Alignment.Bottom,
    ) {
        Row(
            Modifier
                .weight(1f)
                .clip(pillShape)
                .background(scheme.surfaceContainerHigh)
                .border(1.dp, scheme.outlineVariant, pillShape)
                .padding(start = 18.dp, end = 6.dp, top = 4.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            BasicTextField(
                value = value,
                onValueChange = onValueChange,
                modifier = Modifier
                    .weight(1f)
                    .padding(vertical = 10.dp),
                textStyle = MaterialTheme.typography.bodyLarge.copy(color = scheme.onSurface),
                cursorBrush = SolidColor(scheme.primary),
                maxLines = 5,
                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
                decorationBox = { inner ->
                    Box {
                        if (value.isEmpty()) {
                            Text(
                                "Digite sua mensagem…",
                                color = scheme.onSurfaceVariant.copy(alpha = 0.7f),
                                style = MaterialTheme.typography.bodyLarge,
                            )
                        }
                        inner()
                    }
                },
            )
            AnimatedVisibility(visible = value.isNotBlank()) {
                Box(
                    Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(LumaGradient)
                        .clickable(onClick = onSend),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        Icons.AutoMirrored.Rounded.Send,
                        contentDescription = "Enviar",
                        tint = Color.White,
                        modifier = Modifier.size(20.dp),
                    )
                }
            }
        }
        Spacer(Modifier.width(10.dp))
        VoiceButton(phase = phase, onClick = onToggleVoice)
    }
}

@Composable
private fun VoiceButton(phase: VoicePhase, onClick: () -> Unit) {
    val scheme = MaterialTheme.colorScheme
    val active = phase != VoicePhase.Off
    val transition = rememberInfiniteTransition(label = "voice-button")
    val ring by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1600), RepeatMode.Restart),
        label = "ring",
    )
    Box(Modifier.size(56.dp), contentAlignment = Alignment.Center) {
        if (active) {
            Box(
                Modifier
                    .size(52.dp)
                    .graphicsLayer {
                        val s = 1f + 0.35f * ring
                        scaleX = s
                        scaleY = s
                        alpha = 0.45f * (1f - ring)
                    }
                    .background(scheme.primary, CircleShape),
            )
        }
        val buttonModifier = if (active) {
            Modifier.size(52.dp).clip(CircleShape).background(LumaGradient)
        } else {
            Modifier
                .size(52.dp)
                .clip(CircleShape)
                .background(scheme.surfaceContainerHigh)
                .border(1.dp, scheme.outlineVariant, CircleShape)
        }
        Box(buttonModifier.clickable(onClick = onClick), contentAlignment = Alignment.Center) {
            Icon(
                imageVector = if (active) Icons.Rounded.MicOff else Icons.Rounded.Mic,
                contentDescription = if (active) "Desativar Luma por voz" else "Ativar Luma por voz",
                tint = if (active) Color.White else scheme.primary,
            )
        }
    }
}
