package app.luma.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

object LumaColors {
    val Violet = Color(0xFF7C5CFF)
    val Indigo = Color(0xFF4F46E5)
    val Cyan = Color(0xFF22D3EE)
    val Pink = Color(0xFFE879F9)
    val Emerald = Color(0xFF34D399)
    val Amber = Color(0xFFFBBF24)
}

private val DarkColors = darkColorScheme(
    primary = Color(0xFFA48BFF),
    onPrimary = Color(0xFF1B0B5C),
    primaryContainer = Color(0xFF3B2A8F),
    onPrimaryContainer = Color(0xFFE5DEFF),
    secondary = Color(0xFF5CD6F0),
    onSecondary = Color(0xFF00363F),
    secondaryContainer = Color(0xFF0E4B58),
    onSecondaryContainer = Color(0xFFB8F0FF),
    tertiary = Color(0xFFF0A3FF),
    onTertiary = Color(0xFF4A0F57),
    background = Color(0xFF0C0B16),
    onBackground = Color(0xFFE8E6F4),
    surface = Color(0xFF0C0B16),
    onSurface = Color(0xFFE8E6F4),
    surfaceVariant = Color(0xFF2A2840),
    onSurfaceVariant = Color(0xFFC6C3DA),
    surfaceContainerLowest = Color(0xFF08080F),
    surfaceContainerLow = Color(0xFF12111F),
    surfaceContainer = Color(0xFF181727),
    surfaceContainerHigh = Color(0xFF211F33),
    surfaceContainerHighest = Color(0xFF2B2940),
    outline = Color(0xFF8B88A3),
    outlineVariant = Color(0xFF3A3852),
    error = Color(0xFFFFB4AB),
    onError = Color(0xFF690005),
    errorContainer = Color(0xFF93000A),
    onErrorContainer = Color(0xFFFFDAD6),
)

private val LightColors = lightColorScheme(
    primary = Color(0xFF5B3DF5),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFE5DEFF),
    onPrimaryContainer = Color(0xFF1B0B5C),
    secondary = Color(0xFF006A7C),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFB8F0FF),
    onSecondaryContainer = Color(0xFF001F26),
    tertiary = Color(0xFF9B30B3),
    onTertiary = Color(0xFFFFFFFF),
    background = Color(0xFFF6F5FB),
    onBackground = Color(0xFF1B1A25),
    surface = Color(0xFFF6F5FB),
    onSurface = Color(0xFF1B1A25),
    surfaceVariant = Color(0xFFE6E3F2),
    onSurfaceVariant = Color(0xFF48465A),
    surfaceContainerLowest = Color(0xFFFFFFFF),
    surfaceContainerLow = Color(0xFFF1EFF9),
    surfaceContainer = Color(0xFFFFFFFF),
    surfaceContainerHigh = Color(0xFFEDEAF7),
    surfaceContainerHighest = Color(0xFFE6E3F2),
    outline = Color(0xFF7A7791),
    outlineVariant = Color(0xFFD5D2E4),
    error = Color(0xFFBA1A1A),
    onError = Color(0xFFFFFFFF),
    errorContainer = Color(0xFFFFDAD6),
    onErrorContainer = Color(0xFF410002),
)

private val base = Typography()

private val LumaTypography = base.copy(
    displaySmall = base.displaySmall.copy(fontWeight = FontWeight.Bold, letterSpacing = (-0.5).sp),
    headlineMedium = base.headlineMedium.copy(fontWeight = FontWeight.Bold),
    headlineSmall = base.headlineSmall.copy(fontWeight = FontWeight.SemiBold),
    titleLarge = base.titleLarge.copy(fontWeight = FontWeight.SemiBold),
    titleMedium = base.titleMedium.copy(fontWeight = FontWeight.SemiBold),
    bodyLarge = base.bodyLarge.copy(lineHeight = 24.sp),
)

private val LumaShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(24.dp),
)

@Composable
fun LumaTheme(darkTheme: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = LumaTypography,
        shapes = LumaShapes,
        content = content,
    )
}
