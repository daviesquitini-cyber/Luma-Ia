package app.luma.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.luma.ui.theme.LumaColors
import app.luma.voice.VoicePhase
import coil.compose.AsyncImage
import kotlin.math.PI
import kotlin.math.sin

val LumaGradient: Brush
    get() = Brush.linearGradient(listOf(LumaColors.Indigo, LumaColors.Violet, LumaColors.Pink))

@Composable
fun LumaBackground(modifier: Modifier = Modifier) {
    val dark = isSystemInDarkTheme()
    Box(
        modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .drawBehind {
                drawRect(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            LumaColors.Violet.copy(alpha = if (dark) 0.28f else 0.16f),
                            Color.Transparent,
                        ),
                        center = Offset(size.width * 0.15f, 0f),
                        radius = size.width * 1.1f,
                    ),
                )
                drawRect(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            LumaColors.Cyan.copy(alpha = if (dark) 0.14f else 0.10f),
                            Color.Transparent,
                        ),
                        center = Offset(size.width, size.height * 0.85f),
                        radius = size.width * 0.9f,
                    ),
                )
            },
    )
}

/** Orbe animado que reage ao estado da voz. */
@Composable
fun VoiceOrb(phase: VoicePhase, modifier: Modifier = Modifier, diameter: Dp = 120.dp) {
    val transition = rememberInfiniteTransition(label = "orb")
    val periodMs = when (phase) {
        VoicePhase.Off -> 5200
        VoicePhase.Waiting -> 3600
        VoicePhase.Listening -> 1400
        VoicePhase.Thinking -> 2200
        VoicePhase.Speaking -> 900
    }
    val pulse by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(periodMs, easing = LinearEasing)),
        label = "pulse",
    )
    val spin by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            tween(if (phase == VoicePhase.Thinking) 2500 else 9000, easing = LinearEasing),
        ),
        label = "spin",
    )
    val amplitude by animateFloatAsState(
        targetValue = when (phase) {
            VoicePhase.Off -> 0.02f
            VoicePhase.Waiting -> 0.05f
            VoicePhase.Listening -> 0.12f
            VoicePhase.Thinking -> 0.06f
            VoicePhase.Speaking -> 0.16f
        },
        label = "amplitude",
    )
    val saturation by animateFloatAsState(
        targetValue = if (phase == VoicePhase.Off) 0.45f else 1f,
        label = "saturation",
    )

    Canvas(modifier.size(diameter)) {
        val r = this.size.minDimension / 2f
        val c = this.center
        val wave = (sin(pulse * 2f * PI.toFloat()) + 1f) / 2f
        val coreR = r * (0.52f + amplitude * wave)
        val glowAlpha = (0.20f + 0.35f * wave) * saturation

        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(LumaColors.Violet.copy(alpha = glowAlpha), Color.Transparent),
                center = c,
                radius = r,
            ),
            radius = r,
            center = c,
        )

        if (phase == VoicePhase.Listening || phase == VoicePhase.Speaking) {
            for (i in 0..1) {
                val p = (pulse + i * 0.5f) % 1f
                drawCircle(
                    color = LumaColors.Cyan.copy(alpha = (1f - p) * 0.35f),
                    radius = coreR + (r - coreR) * p,
                    center = c,
                    style = Stroke(width = r * 0.025f),
                )
            }
        }

        rotate(degrees = spin, pivot = c) {
            drawCircle(
                brush = Brush.sweepGradient(
                    colors = listOf(LumaColors.Violet, LumaColors.Pink, LumaColors.Cyan, LumaColors.Violet),
                    center = c,
                ),
                radius = coreR,
                center = c,
                alpha = saturation,
            )
        }

        val highlight = c + Offset(-coreR * 0.28f, -coreR * 0.32f)
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color.White.copy(alpha = 0.55f), Color.Transparent),
                center = highlight,
                radius = coreR * 0.55f,
            ),
            radius = coreR * 0.55f,
            center = highlight,
        )
    }
}

@Composable
fun TypingDots(modifier: Modifier = Modifier, color: Color = MaterialTheme.colorScheme.primary) {
    val transition = rememberInfiniteTransition(label = "dots")
    val t by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1200, easing = LinearEasing)),
        label = "dots",
    )
    Row(
        modifier,
        horizontalArrangement = Arrangement.spacedBy(5.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        repeat(3) { i ->
            val a = 0.3f + 0.7f * ((sin((t - i * 0.16f) * 2f * PI.toFloat()) + 1f) / 2f)
            Box(
                Modifier
                    .size(7.dp)
                    .clip(CircleShape)
                    .background(color.copy(alpha = a)),
            )
        }
    }
}

@Composable
fun GoogleLogo(modifier: Modifier = Modifier, diameter: Dp = 20.dp) {
    Canvas(modifier.size(diameter)) {
        val sw = this.size.minDimension * 0.2f
        val arcSize = Size(this.size.width - sw, this.size.height - sw)
        val topLeft = Offset(sw / 2f, sw / 2f)
        val stroke = Stroke(width = sw, cap = StrokeCap.Butt)
        drawArc(Color(0xFFEA4335), 200f, 115f, false, topLeft, arcSize, style = stroke)
        drawArc(Color(0xFFFBBC05), 140f, 62f, false, topLeft, arcSize, style = stroke)
        drawArc(Color(0xFF34A853), 40f, 102f, false, topLeft, arcSize, style = stroke)
        drawArc(Color(0xFF4285F4), 0f, 42f, false, topLeft, arcSize, style = stroke)
        drawRect(
            color = Color(0xFF4285F4),
            topLeft = Offset(this.size.width / 2f, this.size.height / 2f - sw / 2f),
            size = Size(this.size.width / 2f - sw / 2f + 1f, sw),
        )
    }
}

@Composable
fun GoogleButton(
    onClick: () -> Unit,
    busy: Boolean,
    modifier: Modifier = Modifier,
    label: String = "Continuar com Google",
) {
    Button(
        onClick = onClick,
        enabled = !busy,
        modifier = modifier
            .fillMaxWidth()
            .height(54.dp),
        shape = RoundedCornerShape(27.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = Color.White,
            contentColor = Color(0xFF1F1F1F),
            disabledContainerColor = Color.White.copy(alpha = 0.7f),
            disabledContentColor = Color(0xFF1F1F1F).copy(alpha = 0.7f),
        ),
        border = BorderStroke(1.dp, Color(0xFFDADCE0)),
    ) {
        if (busy) {
            CircularProgressIndicator(
                modifier = Modifier.size(20.dp),
                strokeWidth = 2.dp,
                color = Color(0xFF4285F4),
            )
        } else {
            GoogleLogo(diameter = 20.dp)
        }
        Spacer(Modifier.width(12.dp))
        Text(label, fontWeight = FontWeight.Medium, fontSize = 16.sp)
    }
}

@Composable
fun Avatar(name: String, photoUrl: String, diameter: Dp, modifier: Modifier = Modifier) {
    Box(
        modifier
            .size(diameter)
            .clip(CircleShape)
            .background(LumaGradient),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = name.trim().take(1).uppercase().ifBlank { "L" },
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = (diameter.value * 0.42f).sp,
        )
        if (photoUrl.isNotBlank()) {
            AsyncImage(
                model = photoUrl,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
            )
        }
    }
}
