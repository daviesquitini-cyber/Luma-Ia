package app.luma.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import app.luma.AppConfig
import app.luma.data.Settings
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(
    settings: Settings,
    googleBusy: Boolean,
    googleError: String?,
    onBack: () -> Unit,
    onSave: (Settings) -> Unit,
    onClearHistory: () -> Unit,
    onGoogleSignIn: () -> Unit,
    onSignOut: () -> Unit,
) {
    val scheme = MaterialTheme.colorScheme
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }

    var userName by remember(settings.userName) { mutableStateOf(settings.userName) }
    var apiKey by remember(settings.apiKey) { mutableStateOf(settings.apiKey) }
    var model by remember(settings.model) { mutableStateOf(settings.model) }
    var cartesiaKey by remember(settings.cartesiaKey) { mutableStateOf(settings.cartesiaKey) }
    var voiceId by remember(settings.voiceId) { mutableStateOf(settings.voiceId) }
    var clientId by remember(settings.googleClientId) { mutableStateOf(settings.googleClientId) }
    var confirmClear by remember { mutableStateOf(false) }

    Box(Modifier.fillMaxSize()) {
        LumaBackground()
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(start = 6.dp, end = 16.dp, top = 6.dp, bottom = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Voltar")
                }
                Text("Configurações", style = MaterialTheme.typography.titleLarge)
            }

            Column(
                Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                SectionCard("Conta") {
                    if (settings.userEmail.isNotBlank()) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Avatar(name = settings.userName, photoUrl = settings.userPhoto, diameter = 52.dp)
                            Spacer(Modifier.width(14.dp))
                            Column {
                                Text(
                                    settings.userName.ifBlank { "Conta Google" },
                                    style = MaterialTheme.typography.titleMedium,
                                )
                                Text(
                                    settings.userEmail,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = scheme.onSurfaceVariant,
                                )
                            }
                        }
                        OutlinedButton(onClick = onSignOut) { Text("Sair da conta") }
                    } else {
                        Text(
                            "Você está usando a Luma sem conta. Entre com o Google para personalizar seu perfil.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = scheme.onSurfaceVariant,
                        )
                        GoogleButton(onClick = onGoogleSignIn, busy = googleBusy)
                    }
                    googleError?.let {
                        Text(it, color = scheme.error, style = MaterialTheme.typography.bodySmall)
                    }
                    LumaField(
                        value = userName,
                        onValueChange = { userName = it },
                        label = "Como a Luma deve te chamar",
                        placeholder = AppConfig.DEFAULT_USER_NAME,
                    )
                }

                SectionCard("Inteligência artificial") {
                    LumaField(
                        value = apiKey,
                        onValueChange = { apiKey = it },
                        label = "Chave da API (Groq)",
                        secret = true,
                    )
                    LumaField(
                        value = model,
                        onValueChange = { model = it },
                        label = "Modelo (padrão: ${AppConfig.DEFAULT_MODEL})",
                    )
                }

                SectionCard("Voz") {
                    LumaField(
                        value = cartesiaKey,
                        onValueChange = { cartesiaKey = it },
                        label = "Chave da API Cartesia",
                        secret = true,
                    )
                    LumaField(
                        value = voiceId,
                        onValueChange = { voiceId = it },
                        label = "Voice ID da Cartesia",
                    )
                }

                SectionCard("Login com Google") {
                    Text(
                        "Para ativar o login, crie no Google Cloud um ID de cliente Android com o pacote e " +
                            "o SHA-1 abaixo e um ID de cliente Web. Cole o ID Web aqui.",
                        style = MaterialTheme.typography.bodySmall,
                        color = scheme.onSurfaceVariant,
                    )
                    LumaField(
                        value = clientId,
                        onValueChange = { clientId = it },
                        label = "Client ID Web do Google",
                        placeholder = "123456-abc.apps.googleusercontent.com",
                    )
                    CopyRow("Pacote", AppConfig.PACKAGE_NAME)
                    CopyRow("SHA-1", AppConfig.DEBUG_SHA1)
                }

                SectionCard("Dados") {
                    OutlinedButton(
                        onClick = { confirmClear = true },
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Icon(Icons.Rounded.Delete, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Limpar todo o histórico")
                    }
                }

                SectionCard("Sobre") {
                    Text(
                        "Criador: ${AppConfig.CREATOR}",
                        style = MaterialTheme.typography.titleMedium,
                    )
                    Text(
                        "Luma ${AppConfig.VERSION}",
                        style = MaterialTheme.typography.bodySmall,
                        color = scheme.onSurfaceVariant,
                    )
                }
                Spacer(Modifier.height(96.dp))
            }
        }

        Button(
            onClick = {
                onSave(
                    settings.copy(
                        userName = userName.trim(),
                        apiKey = apiKey.trim(),
                        model = model.trim().ifBlank { AppConfig.DEFAULT_MODEL },
                        cartesiaKey = cartesiaKey.trim(),
                        voiceId = voiceId.trim().ifBlank { AppConfig.DEFAULT_VOICE_ID },
                        googleClientId = clientId.trim(),
                    ),
                )
                scope.launch { snackbar.showSnackbar("Configurações salvas") }
            },
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .imePadding()
                .padding(16.dp)
                .fillMaxWidth()
                .height(54.dp),
            shape = RoundedCornerShape(27.dp),
        ) {
            Text("Salvar", fontWeight = FontWeight.SemiBold)
        }

        SnackbarHost(
            hostState = snackbar,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(bottom = 86.dp),
        ) { data -> Snackbar(snackbarData = data, shape = RoundedCornerShape(16.dp)) }
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("Limpar histórico?") },
            text = {
                Text("Todas as conversas (texto e voz) serão apagadas e a Luma esquecerá o contexto.")
            },
            confirmButton = {
                TextButton(onClick = {
                    confirmClear = false
                    onClearHistory()
                }) { Text("Limpar todo o histórico") }
            },
            dismissButton = {
                TextButton(onClick = { confirmClear = false }) { Text("Cancelar") }
            },
        )
    }
}

@Composable
private fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Surface(
        shape = RoundedCornerShape(24.dp),
        color = MaterialTheme.colorScheme.surfaceContainer,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f)),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(
                title,
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold,
            )
            content()
        }
    }
}

@Composable
private fun LumaField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    secret: Boolean = false,
    placeholder: String? = null,
) {
    var visible by remember { mutableStateOf(false) }
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = Modifier.fillMaxWidth(),
        label = { Text(label) },
        placeholder = if (placeholder != null) {
            { Text(placeholder) }
        } else {
            null
        },
        singleLine = true,
        shape = RoundedCornerShape(16.dp),
        visualTransformation = if (secret && !visible) PasswordVisualTransformation() else VisualTransformation.None,
        keyboardOptions = KeyboardOptions(keyboardType = if (secret) KeyboardType.Password else KeyboardType.Text),
        trailingIcon = if (secret) {
            {
                IconButton(onClick = { visible = !visible }) {
                    Icon(
                        if (visible) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility,
                        contentDescription = if (visible) "Ocultar" else "Mostrar",
                    )
                }
            }
        } else {
            null
        },
    )
}

@Composable
private fun CopyRow(label: String, value: String) {
    val clipboard = LocalClipboardManager.current
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(
                label,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            SelectionContainer {
                Text(value, style = MaterialTheme.typography.bodyMedium)
            }
        }
        IconButton(onClick = { clipboard.setText(AnnotatedString(value)) }) {
            Icon(Icons.Rounded.ContentCopy, contentDescription = "Copiar $label")
        }
    }
}
