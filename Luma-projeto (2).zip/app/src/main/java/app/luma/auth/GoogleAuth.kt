package app.luma.auth

import android.app.Activity
import android.content.Context
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.GetCredentialException
import androidx.credentials.exceptions.NoCredentialException
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenParsingException

data class GoogleProfile(val name: String, val email: String, val photo: String)

object GoogleAuth {

    sealed class Result {
        data class Success(val profile: GoogleProfile) : Result()
        data class Error(val message: String) : Result()
        object Cancelled : Result()
    }

    suspend fun signIn(activity: Activity, webClientId: String): Result {
        if (webClientId.isBlank()) {
            return Result.Error("Informe o Client ID Web do Google em Configurações > Login com Google.")
        }
        val option = GetGoogleIdOption.Builder()
            .setFilterByAuthorizedAccounts(false)
            .setServerClientId(webClientId.trim())
            .setAutoSelectEnabled(false)
            .build()
        val request = GetCredentialRequest.Builder()
            .addCredentialOption(option)
            .build()

        return try {
            val response = CredentialManager.create(activity).getCredential(activity, request)
            val credential = response.credential
            if (credential is CustomCredential &&
                credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
            ) {
                val google = GoogleIdTokenCredential.createFrom(credential.data)
                val name = google.displayName
                    ?: google.givenName
                    ?: google.id.substringBefore('@')
                Result.Success(
                    GoogleProfile(
                        name = name,
                        email = google.id,
                        photo = google.profilePictureUri?.toString().orEmpty(),
                    ),
                )
            } else {
                Result.Error("Credencial do Google inesperada.")
            }
        } catch (e: GetCredentialCancellationException) {
            Result.Cancelled
        } catch (e: NoCredentialException) {
            Result.Error(
                "Nenhuma conta Google disponível. Verifique se há uma conta no aparelho e se o app " +
                    "foi cadastrado no Google Cloud (pacote + SHA-1).",
            )
        } catch (e: GetCredentialException) {
            Result.Error("Falha no login com Google: ${e.message ?: e.type}")
        } catch (e: GoogleIdTokenParsingException) {
            Result.Error("Resposta inválida do Google.")
        }
    }

    suspend fun signOut(context: Context) {
        try {
            CredentialManager.create(context).clearCredentialState(ClearCredentialStateRequest())
        } catch (e: Exception) {
            // sem problema: o perfil local é apagado de qualquer forma
        }
    }
}
