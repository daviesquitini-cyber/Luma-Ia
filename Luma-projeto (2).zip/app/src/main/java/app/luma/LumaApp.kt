package app.luma

import android.app.Application
import app.luma.data.AppDatabase
import app.luma.data.ChatRepository
import app.luma.data.SettingsStore

class LumaApp : Application() {
    val database: AppDatabase by lazy { AppDatabase.build(this) }
    val settingsStore: SettingsStore by lazy { SettingsStore(this) }
    val repository: ChatRepository by lazy { ChatRepository(database) }
}
