package app.luma.voice

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import app.luma.AppConfig
import app.luma.LumaApp
import app.luma.R
import app.luma.firstName
import app.luma.net.ApiException
import app.luma.net.CartesiaClient
import app.luma.net.ChatTurn
import app.luma.net.OpenAiClient
import app.luma.net.Prompts
import app.luma.ui.MainActivity
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/**
 * Serviço em primeiro plano: fica esperando a palavra "Luma", abre uma sessão de
 * conversa por voz (ouve, pensa, fala) e encerra com "tchau" / "encerrar".
 */
class VoiceService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val mainHandler = Handler(Looper.getMainLooper())
    private var loopJob: Job? = null
    private var sessionJob: Job? = null
    private var recognizer: SpeechRecognizer? = null

    private val openAi = OpenAiClient()
    private val cartesia = CartesiaClient()
    private val hotwordRegex = Regex(AppConfig.HOTWORD_PATTERN, RegexOption.IGNORE_CASE)
    private val endRegex = Regex(AppConfig.END_PATTERN, RegexOption.IGNORE_CASE)

    private val lumaApp: LumaApp get() = application as LumaApp

    private class FatalVoiceError(message: String) : Exception(message)

    private sealed class ListenResult {
        data class Heard(val text: String) : ListenResult()
        object Silence : ListenResult()
        data class Failure(val code: Int) : ListenResult()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                shutdown()
                return START_NOT_STICKY
            }
            ACTION_END_SESSION -> {
                sessionJob?.cancel()
                return START_STICKY
            }
        }
        enterForeground()
        if (loopJob?.isActive != true) {
            _state.update { it.copy(error = null) }
            loopJob = scope.launch { mainLoop() }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        scope.cancel()
        destroyRecognizer()
        _state.update { it.copy(phase = VoicePhase.Off, transcript = "") }
        super.onDestroy()
    }

    // ---------------------------------------------------------------- loop principal

    private suspend fun mainLoop() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            fail("Reconhecimento de voz indisponível neste aparelho.")
            return
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            fail("Sem permissão de microfone.")
            return
        }
        try {
            coroutineScope {
                while (isActive) {
                    setPhase(VoicePhase.Waiting)
                    val heard = waitForHotword()
                    val job = launch { runSession(heard) }
                    sessionJob = job
                    job.join()
                    sessionJob = null
                }
            }
        } catch (e: FatalVoiceError) {
            fail(e.message ?: "Erro de voz.")
        }
    }

    /** Escuta em ciclos até ouvir "Luma". Devolve o que veio depois da palavra (pode ser vazio). */
    private suspend fun waitForHotword(): String {
        var failures = 0
        while (true) {
            when (val result = listen(1200L)) {
                is ListenResult.Heard -> {
                    failures = 0
                    val match = hotwordRegex.find(result.text)
                    if (match != null) {
                        return result.text.substring(match.range.last + 1)
                            .trim { !it.isLetterOrDigit() }
                    }
                }
                ListenResult.Silence -> failures = 0
                is ListenResult.Failure -> {
                    if (result.code == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                        throw FatalVoiceError("Sem permissão de microfone.")
                    }
                    failures++
                    if (failures >= 10) {
                        throw FatalVoiceError("Reconhecimento de voz indisponível neste aparelho.")
                    }
                    delay(700)
                }
            }
        }
    }

    private suspend fun runSession(initial: String) {
        val name = lumaApp.settingsStore.current().userName.firstName()
        _state.update { it.copy(error = null) }
        var pending: String? = initial.takeIf { it.length >= 2 }
        var silences = 0

        if (pending == null) {
            if (!say("Olá, $name")) return
        }
        while (currentCoroutineContext().isActive) {
            val text: String? = pending ?: listenForUser()
            pending = null
            if (text == null) {
                silences++
                if (silences >= 2) return
                continue
            }
            silences = 0
            if (endRegex.containsMatchIn(text)) {
                say("Até logo!")
                return
            }
            if (!answer(text)) return
        }
    }

    private suspend fun listenForUser(): String? {
        setPhase(VoicePhase.Listening)
        return when (val r = listen(2000L) { partial -> _state.update { it.copy(transcript = partial) } }) {
            is ListenResult.Heard -> r.text
            else -> null
        }
    }

    private suspend fun answer(text: String): Boolean {
        setPhase(VoicePhase.Thinking, text)
        val settings = lumaApp.settingsStore.current()
        val repo = lumaApp.repository
        repo.add("user", text, "voice")
        val reply = try {
            val turns = repo.history().map { ChatTurn(it.role, it.content) }
            openAi.chat(
                settings.apiKey,
                settings.model,
                Prompts.system(settings.userName, voice = true),
                turns,
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: ApiException) {
            setError(e.message ?: "Erro ao falar com a IA.")
            return false
        }
        val finalReply = reply.ifBlank { "Não consegui pensar em uma resposta agora." }
        repo.add("assistant", finalReply, "voice")
        return say(finalReply)
    }

    /** Fala o texto com a voz da Cartesia. Devolve false se algo falhar. */
    private suspend fun say(text: String): Boolean {
        val clean = text.replace(Regex("[*_#`>~|\\p{So}]"), "").trim()
        if (clean.isBlank()) return true
        setPhase(VoicePhase.Speaking)
        val settings = lumaApp.settingsStore.current()
        val player = PcmPlayer(AppConfig.SAMPLE_RATE)
        return try {
            player.start()
            cartesia.speak(settings.cartesiaKey, settings.voiceId, clean) { buf, n ->
                player.write(buf, n)
            }
            player.finish()
            true
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            currentCoroutineContext().ensureActive()
            setError(e.message ?: "Falha ao falar.")
            false
        } finally {
            player.release()
        }
    }

    // ---------------------------------------------------------------- reconhecimento

    private suspend fun listen(
        silenceMs: Long,
        onPartial: (String) -> Unit = {},
    ): ListenResult = suspendCancellableCoroutine { cont ->
        val rec = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = rec
        var done = false

        fun dispose() {
            mainHandler.post {
                try {
                    rec.destroy()
                } catch (e: Exception) {
                    // ignora
                }
                if (recognizer === rec) recognizer = null
            }
        }

        fun finish(result: ListenResult) {
            if (done) return
            done = true
            dispose()
            if (cont.isActive) cont.resume(result)
        }

        rec.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}

            override fun onError(error: Int) {
                finish(
                    when (error) {
                        SpeechRecognizer.ERROR_NO_MATCH,
                        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> ListenResult.Silence
                        else -> ListenResult.Failure(error)
                    },
                )
            }

            override fun onResults(results: Bundle?) {
                val text = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                    .orEmpty()
                finish(if (text.isBlank()) ListenResult.Silence else ListenResult.Heard(text))
            }

            override fun onPartialResults(partialResults: Bundle?) {
                val text = partialResults
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                    .orEmpty()
                if (text.isNotBlank()) onPartial(text)
            }
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra("android.speech.extras.SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS", silenceMs)
        }
        rec.startListening(intent)

        cont.invokeOnCancellation {
            done = true
            dispose()
        }
    }

    private fun destroyRecognizer() {
        val rec = recognizer ?: return
        recognizer = null
        try {
            rec.destroy()
        } catch (e: Exception) {
            // ignora
        }
    }

    // ---------------------------------------------------------------- estado / notificação

    private fun setPhase(phase: VoicePhase, transcript: String = "") {
        _state.update { it.copy(phase = phase, transcript = transcript) }
        val text = when (phase) {
            VoicePhase.Waiting -> "Diga “Luma” para conversar"
            else -> phase.label()
        }
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, buildNotification(text))
    }

    private fun setError(message: String) {
        _state.update { it.copy(error = message) }
    }

    private fun fail(message: String) {
        setError(message)
        shutdown()
    }

    private fun shutdown() {
        loopJob?.cancel()
        sessionJob?.cancel()
        destroyRecognizer()
        _state.update { it.copy(phase = VoicePhase.Off, transcript = "") }
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun enterForeground() {
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Luma por voz", NotificationManager.IMPORTANCE_LOW),
        )
        ServiceCompat.startForeground(
            this,
            NOTIFICATION_ID,
            buildNotification("Diga “Luma” para conversar"),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE,
        )
    }

    private fun buildNotification(text: String): Notification {
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            flags,
        )
        val end = PendingIntent.getService(
            this, 2, Intent(this, VoiceService::class.java).setAction(ACTION_END_SESSION), flags,
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, VoiceService::class.java).setAction(ACTION_STOP), flags,
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_luma)
            .setContentTitle("Luma ativa")
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .addAction(0, "Encerrar conversa", end)
            .addAction(0, "Desativar", stop)
            .build()
    }

    companion object {
        const val ACTION_STOP = "app.luma.action.STOP"
        const val ACTION_END_SESSION = "app.luma.action.END_SESSION"
        private const val CHANNEL_ID = "luma_voice"
        private const val NOTIFICATION_ID = 42

        private val _state = MutableStateFlow(VoiceState())
        val state: StateFlow<VoiceState> = _state.asStateFlow()

        fun clearError() {
            _state.update { it.copy(error = null) }
        }

        fun start(context: Context) {
            ContextCompat.startForegroundService(context, Intent(context, VoiceService::class.java))
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, VoiceService::class.java))
        }
    }
}
