package app.luma.voice

enum class VoicePhase { Off, Waiting, Listening, Thinking, Speaking }

data class VoiceState(
    val phase: VoicePhase = VoicePhase.Off,
    val transcript: String = "",
    val error: String? = null,
)

fun VoicePhase.label(): String = when (this) {
    VoicePhase.Off -> "Luma desativada"
    VoicePhase.Waiting -> "Aguardando você dizer “Luma”…"
    VoicePhase.Listening -> "Ouvindo você…"
    VoicePhase.Thinking -> "Luma está digitando…"
    VoicePhase.Speaking -> "Luma falando…"
}
