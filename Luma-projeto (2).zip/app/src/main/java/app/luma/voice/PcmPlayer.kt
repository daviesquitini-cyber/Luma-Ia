package app.luma.voice

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlinx.coroutines.delay

/** Toca PCM 16-bit mono em streaming. */
class PcmPlayer(private val sampleRate: Int) {
    private companion object {
        const val GAIN = 2.5f
    }

    private var track: AudioTrack? = null
    private var carry = -1
    private var frames = 0L
    private var playing = false

    fun start() {
        val min = AudioTrack.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
        )
        val bufferSize = maxOf(if (min > 0) min * 4 else 0, 32768)
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build(),
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(sampleRate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build(),
            )
            .setBufferSizeInBytes(bufferSize)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        if (t.state != AudioTrack.STATE_INITIALIZED) {
            t.release()
            throw IllegalStateException("Falha no AudioTrack (não inicializado)")
        }
        t.setVolume(AudioTrack.getMaxVolume())
        track = t
    }

    /** Recebe um pedaço de bytes (pode terminar no meio de uma amostra de 16 bits). */
    fun write(buf: ByteArray, len: Int) {
        val t = track ?: return
        var start = 0
        var count = len
        if (carry >= 0 && len > 0) {
            val pair = byteArrayOf(carry.toByte(), buf[0])
            carry = -1
            writeAll(t, pair, 0, 2)
            start = 1
            count = len - 1
        }
        if (count <= 0) return
        if (count % 2 == 1) {
            carry = buf[start + count - 1].toInt() and 0xFF
            count -= 1
        }
        if (count > 0) writeAll(t, buf, start, count)
    }

    /** Amplifica as amostras PCM 16-bit (little-endian) com limite para não distorcer. */
    private fun amplify(data: ByteArray, offset: Int, count: Int): ByteArray {
        val out = ByteArray(count)
        var i = 0
        while (i + 1 < count) {
            val lo = data[offset + i].toInt() and 0xFF
            val hi = data[offset + i + 1].toInt()
            val sample = (hi shl 8) or lo
            val boosted = (sample * GAIN).toInt().coerceIn(-32768, 32767)
            out[i] = (boosted and 0xFF).toByte()
            out[i + 1] = ((boosted shr 8) and 0xFF).toByte()
            i += 2
        }
        return out
    }

    private fun writeAll(t: AudioTrack, source: ByteArray, sourceOffset: Int, count: Int) {
        val data = amplify(source, sourceOffset, count)
        val offset = 0
        var written = 0
        while (written < count) {
            val r = t.write(data, offset + written, count - written)
            if (r < 0) throw IllegalStateException("Falha no AudioTrack ($r)")
            written += r
        }
        frames += count / 2
        // Começa a tocar após ~200 ms de áudio acumulado, para evitar cortes.
        if (!playing && frames * 2 >= sampleRate * 2 / 5) {
            t.play()
            playing = true
        }
    }

    /** Espera o áudio acabar de tocar. */
    suspend fun finish() {
        val t = track ?: return
        if (!playing) {
            t.play()
            playing = true
        }
        val deadline = System.currentTimeMillis() + 60_000
        while (t.playbackHeadPosition < frames && System.currentTimeMillis() < deadline) {
            delay(40)
        }
    }

    fun release() {
        val t = track ?: return
        track = null
        try {
            t.pause()
            t.flush()
        } catch (e: Exception) {
            // ignora
        }
        try {
            t.release()
        } catch (e: Exception) {
            // ignora
        }
    }
}
