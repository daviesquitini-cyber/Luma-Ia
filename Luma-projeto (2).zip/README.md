# Luma

Assistente pessoal por voz (Android). Criador: Davi Esquitini.

## Como compilar pelo GitHub
1. Envie **todo o conteúdo desta pasta** para a raiz de um repositório (inclusive a pasta `.github`).
2. Aba **Actions** → **Build Luma APK** → o build roda sozinho a cada envio (ou use *Run workflow*).
3. Ao terminar, baixe o artefato **Luma-debug-apk** (zip com `app-debug.apk`).
4. **Desinstale a versão antiga da Luma antes** de instalar (a assinatura mudou).

Se a pasta `.github` não subir pelo celular: *Add file → Create new file*, nome `.github/workflows/build.yml`, e cole o conteúdo do arquivo.

## Primeiro uso
Configurações → informe a chave da Groq, a chave da Cartesia (o modelo `openai/gpt-oss-20b` e o Voice ID já vêm preenchidos).

## Login com Google (opcional)
1. console.cloud.google.com → crie um projeto → **Tela de consentimento OAuth**.
2. **Credenciais → Criar ID do cliente OAuth → Android**: pacote `app.luma`, SHA-1 `7A:61:E1:36:A5:67:3C:F7:38:5E:34:3B:FB:79:48:5E:91:5F:C7:5B`.
3. **Criar ID do cliente OAuth → Aplicativo da Web** e copie o ID gerado.
4. No app: Configurações → Login com Google → cole o **Client ID Web** → Salvar.
